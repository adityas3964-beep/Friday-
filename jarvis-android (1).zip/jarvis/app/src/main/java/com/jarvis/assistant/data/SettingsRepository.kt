package com.jarvis.assistant.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class Prefs(
    val userName: String = "",
    val wakePhrase: String = "hey jarvis",
    val recogLang: String = "en",   // "en" or "hi" (Vosk model used for commands)
    val ttsLang: String = "en",     // "en" -> en-IN voice, "hi" -> hi-IN voice
    val greeting: String = "",
    val aiEnabled: Boolean = false,
    val aiEndpoint: String = "",    // full URL of an OpenAI-compatible /chat/completions endpoint
    val aiModel: String = ""
)

class SettingsRepository(context: Context) {
    private val sp = context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
    private val _prefs = MutableStateFlow(load())
    val prefs: StateFlow<Prefs> = _prefs

    private fun load() = Prefs(
        userName = sp.getString("userName", "") ?: "",
        wakePhrase = sp.getString("wakePhrase", "hey jarvis") ?: "hey jarvis",
        recogLang = sp.getString("recogLang", "en") ?: "en",
        ttsLang = sp.getString("ttsLang", "en") ?: "en",
        greeting = sp.getString("greeting", "") ?: "",
        aiEnabled = sp.getBoolean("aiEnabled", false),
        aiEndpoint = sp.getString("aiEndpoint", "") ?: "",
        aiModel = sp.getString("aiModel", "") ?: ""
    )

    fun update(transform: (Prefs) -> Prefs) {
        val n = transform(_prefs.value)
        _prefs.value = n
        sp.edit()
            .putString("userName", n.userName)
            .putString("wakePhrase", n.wakePhrase)
            .putString("recogLang", n.recogLang)
            .putString("ttsLang", n.ttsLang)
            .putString("greeting", n.greeting)
            .putBoolean("aiEnabled", n.aiEnabled)
            .putString("aiEndpoint", n.aiEndpoint)
            .putString("aiModel", n.aiModel)
            .apply()
    }

    fun saveApiKey(key: String) {
        sp.edit().putString("aiKey", if (key.isBlank()) "" else SecretStore.encrypt(key.trim())).apply()
    }

    fun apiKey(): String =
        sp.getString("aiKey", "")?.takeIf { it.isNotEmpty() }?.let { SecretStore.decrypt(it) } ?: ""

    fun hasApiKey(): Boolean = !sp.getString("aiKey", "").isNullOrEmpty()

    fun reset() {
        sp.edit().clear().apply()
        _prefs.value = Prefs()
    }
}
