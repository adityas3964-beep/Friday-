package com.jarvis.assistant.command

/** Hinglish normalisation: lowercase, strip punctuation/fillers, map common Devanagari words to Roman. */
object Normalizer {
    private val devanagari = mapOf(
        "खोल" to "khol", "खोलो" to "kholo", "खोलना" to "kholna",
        "यूट्यूब" to "youtube", "यूट्यब" to "youtube",
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वाट्सऐप" to "whatsapp", "व्हॉट्सऐप" to "whatsapp",
        "गूगल" to "google", "सर्च" to "search", "इंस्टाग्राम" to "instagram", "क्रोम" to "chrome",
        "समय" to "samay", "टाइम" to "time", "तारीख" to "tarikh", "तुम्हारा" to "tumhara", "तेरा" to "tera",
        "आपका" to "aapka", "मेरा" to "mera", "नाम" to "naam", "क्या" to "kya", "है" to "hai",
        "वाईफाई" to "wifi", "वाइफाई" to "wifi", "ब्लूटूथ" to "bluetooth", "सेटिंग" to "settings", "सेटिंग्स" to "settings",
        "लॉक" to "lock", "हाँ" to "haan", "हां" to "haan", "नहीं" to "nahi", "रुको" to "ruko",
        "बंद" to "band", "करो" to "karo", "कर" to "kar", "दो" to "do", "भेजो" to "bhejo",
        "मैसेज" to "message", "को" to "ko", "पर" to "par", "में" to "mein", "कैमरा" to "camera",
        "नमस्ते" to "namaste", "धन्यवाद" to "dhanyavad", "शुक्रिया" to "shukriya", "अगली" to "agli", "रील" to "reel"
    )

    private val fillers = setOf("please", "pls", "plz", "sir", "jarvis", "zara", "yaar", "bhai", "ji", "hey")

    fun normalize(raw: String): String {
        val cleaned = raw.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}\\s]"), " ")
        return cleaned.split(Regex("\\s+"))
            .filter { it.isNotEmpty() }
            .map { devanagari[it] ?: it }
            .filter { it !in fillers }
            .joinToString(" ")
    }
}
