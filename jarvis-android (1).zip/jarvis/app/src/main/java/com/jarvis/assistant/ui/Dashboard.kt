package com.jarvis.assistant.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.command.PermissionManager
import com.jarvis.assistant.data.AssistantState
import com.jarvis.assistant.data.VoiceState
import com.jarvis.assistant.voice.VoiceService
import com.jarvis.assistant.voice.VoskEngine
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun rememberResumeTick(): Int {
    val owner = LocalLifecycleOwner.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    return tick
}

@Composable
fun Dashboard() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as JarvisApp
    val state by AssistantState.state.collectAsStateWithLifecycle()
    val heard by AssistantState.heard.collectAsStateWithLifecycle()
    val response by AssistantState.response.collectAsStateWithLifecycle()
    val source by AssistantState.responseSource.collectAsStateWithLifecycle()
    val error by AssistantState.error.collectAsStateWithLifecycle()
    val aiStatus by AssistantState.aiStatus.collectAsStateWithLifecycle()
    val prefs by app.settings.prefs.collectAsStateWithLifecycle()
    val history by app.history.items.collectAsStateWithLifecycle()
    val tick = rememberResumeTick()

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }

    var pendingPtt by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (PermissionManager.mic(ctx)) VoiceService.start(ctx, pendingPtt)
        else AssistantState.error.value = "Microphone permission denied. Voice commands ke liye zaroori hai."
    }
    fun begin(ptt: Boolean) {
        pendingPtt = ptt
        if (PermissionManager.mic(ctx)) VoiceService.start(ctx, ptt)
        else {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            launcher.launch(perms.toTypedArray())
        }
    }

    val active = state in setOf(
        VoiceState.INITIALIZING, VoiceState.WAITING_FOR_WAKE_WORD, VoiceState.LISTENING,
        VoiceState.PROCESSING, VoiceState.AWAITING_CONFIRMATION, VoiceState.SPEAKING
    )
    val micLive = state == VoiceState.WAITING_FOR_WAKE_WORD || state == VoiceState.LISTENING || state == VoiceState.AWAITING_CONFIRMATION

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                HudText("J.A.R.V.I.S", size = 22.sp, color = Hud.Cyan, spacing = 3.sp, weight = FontWeight.Bold, glow = true)
                HudText(if (prefs.userName.isBlank()) "ADMIN: NOT SET" else "ADMIN ${prefs.userName.uppercase()}", size = 11.sp, color = Hud.Sub, spacing = 2.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                HudText("SYSTEM ${if (active) "ACTIVE" else "STANDBY"}", size = 11.sp, color = if (active) Hud.Good else Hud.Sub, spacing = 1.sp)
                HudText("MIC: ${if (micLive) "LIVE" else "OFF"}", size = 11.sp, color = if (micLive) Hud.Warn else Hud.Sub, spacing = 1.sp)
            }
        }

        HudPanel("TIME / DATE") {
            HudText(SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date(now)), size = 30.sp, color = Hud.Cyan,
                weight = FontWeight.Bold, glow = true, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
            HudText(SimpleDateFormat("EEEE, dd MMM yyyy", Locale.getDefault()).format(Date(now)).uppercase(), size = 12.sp, color = Hud.Sub,
                modifier = Modifier.fillMaxWidth(), align = TextAlign.Center, spacing = 2.sp)
        }

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            JarvisCore(state, Modifier.widthIn(max = 320.dp).fillMaxWidth(0.82f))
        }
        HudText(state.name.replace('_', ' '), size = 13.sp, color = if (state == VoiceState.ERROR) Hud.Bad else Hud.Cyan,
            spacing = 3.sp, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
        WaveBars(state)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudButton("START LISTENING", { begin(false) }, Modifier.weight(1f), enabled = !active)
            HudButton("PUSH TO TALK", { begin(true) }, Modifier.weight(1f), color = Hud.Blue,
                enabled = !active || state == VoiceState.WAITING_FOR_WAKE_WORD)
            HudButton("STOP", { VoiceService.stop(ctx) }, Modifier.weight(0.7f), color = Hud.Bad, enabled = active)
        }

        error?.let {
            HudPanel("ALERT") { HudText(it, size = 13.sp, color = Hud.Bad) }
        }

        HudPanel("ASSISTANT") {
            HudText("HEARD", size = 10.sp, color = Hud.Sub)
            HudText(heard.ifBlank { "—" }, size = 14.sp)
            Spacer(Modifier.height(8.dp))
            HudText("RESPONSE ${if (source.isNotBlank()) "[$source]" else ""}", size = 10.sp, color = Hud.Sub)
            HudText(response.ifBlank { "—" }, size = 14.sp, color = Hud.Cyan)
        }

        HudPanel("RECENT COMMANDS") {
            if (history.isEmpty()) HudText("Abhi koi command nahi.", size = 12.sp, color = Hud.Sub)
            history.take(3).forEach {
                HudText("› ${it.heard}", size = 13.sp, color = if (it.ok) Hud.Txt else Hud.Warn)
            }
        }

        val modelOk = remember(tick, prefs.recogLang) { VoskEngine.hasModel(ctx, prefs.recogLang) }
        HudPanel("SERVICE STATUS") {
            StatusRow("MICROPHONE PERMISSION", if (PermissionManager.mic(ctx)) "GRANTED" else "MISSING", PermissionManager.mic(ctx))
            StatusRow("VOICE MODEL (${prefs.recogLang.uppercase()})", if (modelOk) "READY" else "MISSING", modelOk)
            StatusRow("ACCESSIBILITY", if (PermissionManager.accessibility(ctx)) "ENABLED" else "OFF", PermissionManager.accessibility(ctx))
            StatusRow("DISPLAY OVER APPS", if (PermissionManager.overlay(ctx)) "GRANTED" else "MISSING", PermissionManager.overlay(ctx))
            StatusRow("AI PROVIDER", if (prefs.aiEnabled) aiStatus else "OFF (LOCAL ONLY)", if (prefs.aiEnabled) aiStatus == "ONLINE" else null)
        }
        Spacer(Modifier.height(8.dp))
    }
}
