package com.jarvis.assistant.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.command.Cmd
import com.jarvis.assistant.command.CommandDispatcher
import com.jarvis.assistant.command.CommandParser
import com.jarvis.assistant.command.CommandResult
import com.jarvis.assistant.command.WakeMatcher
import com.jarvis.assistant.data.AssistantState
import com.jarvis.assistant.data.HistoryItem
import com.jarvis.assistant.data.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.android.RecognitionListener
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Voice session: WAKE WORD -> GREETING -> LISTEN -> RECOGNIZE -> UNDERSTAND -> CONFIRM -> EXECUTE -> SPEAK -> RESUME.
 * Exactly one microphone session exists at a time; the mic is released before every spoken reply.
 */
class VoiceService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var app: JarvisApp
    private lateinit var engine: VoskEngine
    private lateinit var tts: Tts
    private lateinit var dispatcher: CommandDispatcher

    private var running = false
    private var wakeMode = true
    private var cmdModel: Model? = null
    private var wakeModel: Model? = null
    private var sessionId = 0
    private val handled = AtomicBoolean(false)
    private var lastPartial = ""
    private val turns = ArrayDeque<Pair<String, String>>()

    companion object {
        const val ACTION_START = "com.jarvis.assistant.START"
        const val ACTION_PTT = "com.jarvis.assistant.PTT"
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        private const val CHANNEL = "jarvis_voice"
        private const val NOTIF_ID = 42

        fun start(ctx: Context, pushToTalk: Boolean) {
            val i = Intent(ctx, VoiceService::class.java).setAction(if (pushToTalk) ACTION_PTT else ACTION_START)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, VoiceService::class.java).setAction(ACTION_STOP))
        }
    }

    override fun onCreate() {
        super.onCreate()
        app = application as JarvisApp
        engine = VoskEngine(this)
        tts = Tts(this)
        dispatcher = CommandDispatcher(this, app)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "JARVIS voice session", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> shutdown(VoiceState.STOPPED)
            ACTION_PTT -> begin(pushToTalk = true)
            else -> begin(pushToTalk = false)
        }
        return START_NOT_STICKY   // a mic foreground service cannot be silently restarted from the background on Android 14+
    }

    override fun onDestroy() {
        running = false
        engine.release()
        tts.shutdown()
        scope.cancel()
        if (AssistantState.state.value != VoiceState.ERROR) AssistantState.state.value = VoiceState.STOPPED
        super.onDestroy()
    }

    // ---- lifecycle ----

    private fun begin(pushToTalk: Boolean) {
        if (running) {
            // Never open a second mic session; only allow switching from wake-wait to push-to-talk.
            if (pushToTalk && AssistantState.state.value == VoiceState.WAITING_FOR_WAKE_WORD) {
                sessionId++
                engine.stop()
                listenCommand()
            }
            return
        }
        try { startFg() } catch (e: Exception) {
            AssistantState.error.value = "Foreground service start nahi hua: ${e.message}"
            AssistantState.state.value = VoiceState.ERROR
            stopSelf(); return
        }
        running = true
        wakeMode = !pushToTalk
        AssistantState.error.value = null
        AssistantState.heard.value = ""
        AssistantState.state.value = VoiceState.INITIALIZING
        scope.launch {
            val p = app.settings.prefs.value
            val ok = withContext(Dispatchers.IO) {
                try {
                    cmdModel = engine.model(p.recogLang)
                    wakeModel = if (p.recogLang == "en") cmdModel else (engine.model("en") ?: cmdModel)
                    cmdModel != null
                } catch (t: Throwable) { false }
            }
            if (!running) return@launch
            if (!ok) { fail("Voice model nahi mila (${p.recogLang}). Settings panel > Voice models se download kijiye."); return@launch }
            if (wakeMode) enterWake() else listenCommand()
        }
    }

    private fun startFg() {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("JARVIS microphone active")
            .setContentText("Sun raha hoon. Band karne ke liye Stop dabaiye.")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "STOP", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIF_ID, n)
    }

    private fun shutdown(finalState: VoiceState) {
        running = false
        sessionId++
        engine.stop()
        tts.stop()
        dispatcher.confirmation.clear()
        AssistantState.state.value = finalState
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun fail(message: String) {
        AssistantState.error.value = message
        shutdown(VoiceState.ERROR)
    }

    // ---- listening phases ----

    private fun parseJson(h: String?, key: String): String =
        try { JSONObject(h ?: "{}").optString(key, "").trim() } catch (e: Exception) { "" }

    private fun enterWake() {
        if (!running) return
        val m = wakeModel ?: return fail("Wake model load nahi hua")
        AssistantState.state.value = VoiceState.WAITING_FOR_WAKE_WORD
        val id = ++sessionId
        val fired = AtomicBoolean(false)
        fun check(text: String) {
            if (id != sessionId || text.isEmpty()) return
            if (WakeMatcher.matches(text, app.settings.prefs.value.wakePhrase) && fired.compareAndSet(false, true)) {
                engine.stop()
                onWake()
            }
        }
        try {
            engine.listen(m, 0, object : RecognitionListener {
                override fun onPartialResult(h: String?) = check(parseJson(h, "partial"))
                override fun onResult(h: String?) = check(parseJson(h, "text"))
                override fun onFinalResult(h: String?) {}
                override fun onError(e: Exception?) { if (id == sessionId) fail("Mic error: ${e?.message}") }
                override fun onTimeout() {}
            })
        } catch (e: Exception) { fail("Microphone shuru nahi hua: ${e.message}") }
    }

    private fun onWake() {
        if (!running) return
        val p = app.settings.prefs.value
        val who = p.userName.ifBlank { "sir" }
        val greeting = p.greeting.ifBlank { "Haan $who, boliye. Main sun raha hoon." }
        AssistantState.response.value = greeting
        AssistantState.responseSource.value = "LOCAL"
        AssistantState.state.value = VoiceState.SPEAKING
        tts.speak(greeting, p.ttsLang) { if (running) listenCommand() }
    }

    private fun listenCommand() {
        if (!running) return
        val m = cmdModel ?: return fail("Voice model load nahi hua")
        AssistantState.state.value =
            if (dispatcher.confirmation.hasPending) VoiceState.AWAITING_CONFIRMATION else VoiceState.LISTENING
        AssistantState.heard.value = ""
        lastPartial = ""
        handled.set(false)
        val id = ++sessionId
        try {
            engine.listen(m, 10000, object : RecognitionListener {
                override fun onPartialResult(h: String?) {
                    if (id != sessionId) return
                    val t = parseJson(h, "partial")
                    if (t.isNotEmpty()) { lastPartial = t; AssistantState.heard.value = t }
                }
                override fun onResult(h: String?) { if (id == sessionId) handleText(parseJson(h, "text")) }
                override fun onFinalResult(h: String?) { if (id == sessionId) handleText(parseJson(h, "text")) }
                override fun onError(e: Exception?) { if (id == sessionId) fail("Mic error: ${e?.message}") }
                override fun onTimeout() {
                    if (id != sessionId) return
                    if (lastPartial.isNotEmpty()) handleText(lastPartial)
                    else { dispatcher.confirmation.clear(); resume() }
                }
            })
        } catch (e: Exception) { fail("Microphone shuru nahi hua: ${e.message}") }
    }

    private fun handleText(text: String) {
        if (text.isEmpty() || !handled.compareAndSet(false, true)) return   // never execute a command twice
        sessionId++
        engine.stop()
        AssistantState.state.value = VoiceState.PROCESSING
        AssistantState.heard.value = text
        scope.launch {
            val cmd = CommandParser.parse(text)
            val result = try {
                dispatcher.dispatch(cmd, turns.toList())
            } catch (t: Throwable) {
                CommandResult(false, "Kuch gadbad ho gayi: ${t.message}")
            }
            if (!running) return@launch
            app.history.add(HistoryItem(System.currentTimeMillis(), text, result.message, result.source, result.success))
            turns.addLast(text to result.message)
            while (turns.size > 4) turns.removeFirst()
            reply(result)
        }
    }

    private fun reply(r: CommandResult) {
        AssistantState.response.value = r.message
        AssistantState.responseSource.value = r.source
        AssistantState.state.value = VoiceState.SPEAKING
        tts.speak(r.message, app.settings.prefs.value.ttsLang) {
            if (!running) return@speak
            when {
                r.stopSession -> shutdown(VoiceState.STOPPED)
                dispatcher.confirmation.hasPending -> listenCommand()   // wait for yes/no
                else -> resume()
            }
        }
    }

    /** SPEAK -> RESUME LISTENING. Push-to-talk sessions end after one command. */
    private fun resume() {
        if (!running) return
        if (wakeMode) enterWake() else shutdown(VoiceState.STOPPED)
    }
}
