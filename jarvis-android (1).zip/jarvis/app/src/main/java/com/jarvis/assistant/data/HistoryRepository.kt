package com.jarvis.assistant.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(
    val time: Long,
    val heard: String,
    val reply: String,
    val source: String,   // LOCAL or AI
    val ok: Boolean
)

class HistoryRepository(context: Context) {
    private val sp = context.getSharedPreferences("jarvis_history", Context.MODE_PRIVATE)
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<HistoryItem>> = _items

    private fun load(): List<HistoryItem> = try {
        val arr = JSONArray(sp.getString("items", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryItem(o.getLong("t"), o.getString("h"), o.getString("r"), o.optString("s", "LOCAL"), o.optBoolean("ok", true))
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun persist(list: List<HistoryItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("t", it.time).put("h", it.heard).put("r", it.reply).put("s", it.source).put("ok", it.ok))
        }
        sp.edit().putString("items", arr.toString()).apply()
    }

    fun add(item: HistoryItem) {
        val list = (listOf(item) + _items.value).take(50)
        _items.value = list
        persist(list)
    }

    fun clear() {
        _items.value = emptyList()
        sp.edit().remove("items").apply()
    }
}
