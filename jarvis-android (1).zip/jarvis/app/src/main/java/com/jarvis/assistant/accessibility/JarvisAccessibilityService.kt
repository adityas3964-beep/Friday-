package com.jarvis.assistant.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Least-privilege helper. Declared package filter: WhatsApp only (for locating the Send button).
 * Global actions and gestures do not read any screen content.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* no passive monitoring */ }
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun swipe(up: Boolean): Boolean {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val from = m.heightPixels * (if (up) 0.78f else 0.25f)
        val to = m.heightPixels * (if (up) 0.25f else 0.78f)
        val path = Path().apply { moveTo(x, from); lineTo(x, to) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 260)).build()
        return dispatchGesture(g, null, null)
    }

    fun global(action: Int): Boolean = performGlobalAction(action)

    fun lockScreen(): Boolean =
        Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)

    /** Clicks WhatsApp's Send button if it is currently visible. Returns true only if a click was performed. */
    fun clickWhatsAppSend(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString()?.startsWith("com.whatsapp") != true) return false
        val target = findSend(root) ?: return false
        var n: AccessibilityNodeInfo? = target
        while (n != null) {
            if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }

    private fun findSend(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val d = node.contentDescription?.toString()?.trim()
        if (d != null && (d.equals("Send", true) || d == "भेजें")) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            findSend(c)?.let { return it }
        }
        return null
    }

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
    }
}
