package com.jarvis.assistant.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Minimal client for any OpenAI-compatible /chat/completions endpoint (local server, self-hosted, or a provider you choose). */
object AiClient {
    suspend fun chat(
        endpoint: String, apiKey: String, model: String, userName: String,
        turns: List<Pair<String, String>>, userText: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val msgs = JSONArray()
            msgs.put(JSONObject().put("role", "system").put("content",
                "You are JARVIS, a concise voice assistant. Reply in the user's language (Hindi/Hinglish/English) in at most two short sentences." +
                    if (userName.isNotBlank()) " Address the user as $userName." else ""))
            turns.forEach {
                msgs.put(JSONObject().put("role", "user").put("content", it.first))
                msgs.put(JSONObject().put("role", "assistant").put("content", it.second))
            }
            msgs.put(JSONObject().put("role", "user").put("content", userText))
            val body = JSONObject().put("messages", msgs).apply { if (model.isNotBlank()) put("model", model) }

            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 8000; readTimeout = 20000; doOutput = true
                setRequestProperty("Content-Type", "application/json")
                if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        }
    }
}
